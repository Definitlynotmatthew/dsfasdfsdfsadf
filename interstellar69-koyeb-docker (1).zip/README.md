# 🚀 Interstellar 69 Proxy (Docker-Ready for Koyeb)

Ultraviolet-based proxy with password protection and custom branding.

## 🛡️ Login:
- **Username**: user
- **Password**: 6969

## 🐳 How to Deploy on Koyeb with Docker

1. Push this folder to a GitHub repo
2. Go to [https://app.koyeb.com](https://app.koyeb.com)
3. Create a new **Web Service**
4. Choose **GitHub** as source
5. Pick this repo
6. Koyeb will auto-detect the Dockerfile and deploy

You're done 🎉